﻿<?php

$host = '127.0.0.1';
$u = 'root';
$p = 'juejue';
$dbname = 'chat_sql';
$db = new mysqli($host, $u, $p, $dbname);

if ($db->connect_errno != 0) {
    die("连接失败: " . $conn->connect_error);
}
//连接数据库
